function quizValid() {
    
	var quiztietle = document.getElementById("title");
	 var passScore = document.getElementById("passscore");
    
    if(quiztietle==""||passScore==""){
        
        return false;
    }
    else{
        return true;
    }
}